﻿using Castle_Windsor_Demo.Implementation;
using Castle_Windsor_Demo.Interfaces;
using Moq;
using NUnit.Framework;

namespace Castle_Windsor_Demo_Tests
{
    [TestFixture]
    public class DucatiTests
    {
        private Ducati _ducati;
        private Mock<INamedInterface> _namedInterface;
        private Mock<ILogService> _logService
            ;

        [SetUp]
        public void BeforeEachTest()
        {
            _namedInterface = new Mock<INamedInterface>();
            _logService = new Mock<ILogService>();
            _ducati = new Ducati(_namedInterface.Object, _logService.Object);
        }

        [Test]
        public void TestGettingOnTheBike()
        {
            _ducati.GetOnTheBike();
            _logService.Verify(p=>p.DoSomething(), Times.Once);
            Assert.AreEqual(_ducati.Speed, 0);
        }
    }
}