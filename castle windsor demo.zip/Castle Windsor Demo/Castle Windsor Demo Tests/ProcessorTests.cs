﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Castle_Windsor_Demo;
using Castle_Windsor_Demo.Factories;
using Castle_Windsor_Demo.Interfaces;
using Moq;
using NUnit.Framework;

namespace Castle_Windsor_Demo_Tests
{
    [TestFixture]
    public class ProcessorTests
    {
        private Processor _processor;
        private Mock<ICar> _carInterface;
        private Mock<ISuperCar> _superCarInterface;
        private Mock<IBike> _bike;
        private Mock<IInsaneCarFactory> _insaneCarFactory;
        private Mock<IInsaneCar> _insaneCar;

        [SetUp]
        public void BeforeEachTest()
        {
            _carInterface = new Mock<ICar>();
            _superCarInterface = new Mock<ISuperCar>();
            _bike = new Mock<IBike>();
            _insaneCarFactory = new Mock<IInsaneCarFactory>();
            _insaneCar = new Mock<IInsaneCar>();
            _processor = new Processor(_carInterface.Object, _bike.Object,_insaneCarFactory.Object, _superCarInterface.Object);
        }

        [Test]
        public void Test()
        {
            _insaneCarFactory.Setup(p=>p.GetKoenigsegg()).Returns(_insaneCar.Object);
            _processor.Process();
            _bike.Verify(p=>p.GetOnTheBike(), Times.Once);
            _carInterface.Verify(p => p.StartTheCar(), Times.Once);
            _insaneCar.Verify(p => p.FloorItRidiculously(), Times.Once);
        }
    }
}
