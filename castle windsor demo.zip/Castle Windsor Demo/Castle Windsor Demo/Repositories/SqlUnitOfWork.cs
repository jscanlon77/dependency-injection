﻿using System;
using Castle_Windsor_Demo.Interfaces;

namespace Castle_Windsor_Demo.Repositories
{
    public class SqlUnitOfWork : IUnitOfWork
    {
        public void MakeDatabaseCall()
        {
            Console.WriteLine("We have made database call via unit of work pattern");
        }
    }
}