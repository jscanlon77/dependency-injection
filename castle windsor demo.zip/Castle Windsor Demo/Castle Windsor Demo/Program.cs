﻿using System;
using System.Linq;
using Castle.Windsor;
using Castle.Windsor.Installer;
using Castle_Windsor_Demo.Interfaces;
using Castle_Windsor_Demo.Registration;

namespace Castle_Windsor_Demo
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            // container is disposable so all components in container are controlled by this.
            using (var container = new WindsorContainer())
            {
                // 1. Initializing container from code
                // The different installers could be in different assemblies or in the same
                // so if you want to make your application modular you would have installers in each module.
                container.Install(
                    new ClassesInstaller(),
                    new ServicesInstaller(),
                    new FactoryInstaller());

                WriteAllContainerObjects(container);

                Console.WriteLine("############################  START ##########################");

                var processor = container.Resolve<IProcessor>();
                processor.Process();

                Console.WriteLine("############################  END ##########################");
                
                // 2. Initializing from configuration

                //container.Install(
                //   Configuration.FromXmlFile(@"Configuration.xml")
                //   );

               

                Console.ReadLine();
            }
            
        }

        private static void WriteAllContainerObjects(WindsorContainer container)
        {
            foreach (var handler in container.Kernel.GetAssignableHandlers(typeof(object)))
            {
                Console.WriteLine("{0} {1}",
                   handler.ComponentModel.Name,
                   handler.ComponentModel.Implementation);
                Console.WriteLine();
            }

           
        }
    }
}