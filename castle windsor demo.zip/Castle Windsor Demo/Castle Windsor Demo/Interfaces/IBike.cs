﻿namespace Castle_Windsor_Demo.Interfaces
{
    public interface IBike
    {
        int Speed { get; set; }
        void StartHerUp();
        void GetOnTheBike();
    }
}
