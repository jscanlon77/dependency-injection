﻿namespace Castle_Windsor_Demo.Interfaces
{
    public interface INamedInterface
    {
    }
}