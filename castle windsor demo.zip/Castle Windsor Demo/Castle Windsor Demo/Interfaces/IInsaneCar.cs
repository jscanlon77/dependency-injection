﻿namespace Castle_Windsor_Demo.Interfaces
{
    public interface IInsaneCar
    {
        void FloorItRidiculously();
    }
}