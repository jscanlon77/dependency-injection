﻿namespace Castle_Windsor_Demo.Interfaces
{
    public interface ICar
    {
        void StartTheCar();
    }
}