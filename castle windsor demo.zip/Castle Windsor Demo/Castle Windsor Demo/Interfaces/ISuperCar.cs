﻿namespace Castle_Windsor_Demo.Interfaces
{
    public interface ISuperCar
    {
        void TellTheCarToStart();
    }
}