﻿namespace Castle_Windsor_Demo.Interfaces
{
    public interface IUnitOfWork
    {
        void MakeDatabaseCall();
    }
}