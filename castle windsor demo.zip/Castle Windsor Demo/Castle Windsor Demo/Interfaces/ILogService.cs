﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Castle_Windsor_Demo.Interfaces
{
    public interface ILogService
    {
        string LogDirectory { get; set; }
        void DoSomething();
    }
}
