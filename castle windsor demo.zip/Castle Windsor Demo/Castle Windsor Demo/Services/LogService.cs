﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Castle_Windsor_Demo.Interfaces;

namespace Castle_Windsor_Demo.Services
{
    public class LogService : ILogService
    {
        public string LogDirectory { get; set; }
        public void DoSomething()
        {
            LogDirectory = "some directory";
        }
    }
}
