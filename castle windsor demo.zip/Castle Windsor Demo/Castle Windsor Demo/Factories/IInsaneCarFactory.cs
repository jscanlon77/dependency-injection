﻿using Castle_Windsor_Demo.Interfaces;

namespace Castle_Windsor_Demo.Factories
{
    public interface IInsaneCarFactory
    {
        IInsaneCar GetBugatti();
        IInsaneCar GetKoenigsegg();
    }
}