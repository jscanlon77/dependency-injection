﻿using Castle_Windsor_Demo.Factories;
using Castle_Windsor_Demo.Interfaces;

namespace Castle_Windsor_Demo
{
    public class Processor : IProcessor
    {
        private readonly ICar _car;
        private readonly IBike _bike;
        private readonly IInsaneCarFactory _insaneCarFactory;


        public Processor(ICar car, IBike bike, IInsaneCarFactory insaneCarFactory, ISuperCar superCar)
        {
            _car = car;
            _bike = bike;
            _insaneCarFactory = insaneCarFactory;
        }

        public void Process()
        {
            _bike.GetOnTheBike();
            _car.StartTheCar();
            // Show that we can get a specific car from the factory
            var insaneCar = _insaneCarFactory.GetKoenigsegg();
            insaneCar.FloorItRidiculously();
        }
    }
}