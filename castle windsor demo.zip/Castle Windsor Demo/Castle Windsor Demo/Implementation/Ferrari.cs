﻿using System;
using Castle_Windsor_Demo.Interfaces;

namespace Castle_Windsor_Demo.Implementation
{
    public class Ferrari : ISuperCar
    {
        public void TellTheCarToStart()
        {
            // We have run this method on resolving the component.
            // This is of use if we want to specifically have set something up before creation of the 
            // class which has a dependency.
            Console.WriteLine("We have called the method to start up the Ferrari directly from registration");

        }
    }
}
