﻿using System;
using Castle_Windsor_Demo.Interfaces;

namespace Castle_Windsor_Demo.Implementation
{
    public class Mercedes : ICar
    {
        public void StartTheCar()
        {
            Console.WriteLine("The mercedes has been started");
        }
    }
}