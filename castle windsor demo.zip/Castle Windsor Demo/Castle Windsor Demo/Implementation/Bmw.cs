﻿using Castle_Windsor_Demo.Interfaces;

namespace Castle_Windsor_Demo.Implementation
{
    public class Bmw : ICar
    {
        public void StartTheCar()
        {
            
        }
    }
}