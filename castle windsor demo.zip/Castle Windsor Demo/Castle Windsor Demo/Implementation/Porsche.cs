﻿using System;
using Castle_Windsor_Demo.Interfaces;

namespace Castle_Windsor_Demo.Implementation
{
    public class Porsche : ICar
    {
        private readonly IRepository<IUnitOfWork> _repository;

        public Porsche(IRepository<IUnitOfWork> repository)
        {
            _repository = repository;
        }

        public void StartTheCar()
        {
            Console.WriteLine("The Porsche has been started");
            _repository.RecordStartingCar();
            
        }
    }
}