﻿using System;
using Castle_Windsor_Demo.Interfaces;

namespace Castle_Windsor_Demo.Implementation
{
    public class Koenigsegg : IInsaneCar
    {
        public void FloorItRidiculously()
        {
            Console.WriteLine("The police have confiscated the Koenigsegg and you're doing time!");
        }
    }
}