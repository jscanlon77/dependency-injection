﻿using Castle_Windsor_Demo.Interfaces;

namespace Castle_Windsor_Demo.Implementation
{
    public class Ducati : IBike
    {
        private readonly INamedInterface _namedInterface;
        private readonly ILogService _logService;

        public Ducati(INamedInterface namedInterface, ILogService logService)
        {
            _namedInterface = namedInterface;
            _logService = logService;
        }

        public void StartHerUp()
        {
            _logService.DoSomething();
        }

        public void GetOnTheBike()
        {
            _logService.DoSomething();
            Speed = 0;
        }

        public int Speed { get; set; }
    }
}