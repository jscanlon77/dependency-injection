﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Castle_Windsor_Demo.Interfaces;

namespace Castle_Windsor_Demo.Implementation
{
    public class NamedInterface : INamedInterface
    {
    }
}
