﻿using System;
using Castle_Windsor_Demo.Interfaces;

namespace Castle_Windsor_Demo.Implementation
{
    public class Bugatti : IInsaneCar
    {
        public void FloorItRidiculously()
        {
            Console.WriteLine("The police have confiscated the Bugatti and you're doing time!");
        }
    }
}