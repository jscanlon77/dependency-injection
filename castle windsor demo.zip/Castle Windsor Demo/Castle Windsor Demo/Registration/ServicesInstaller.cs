﻿using Castle.MicroKernel.Registration;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;
using Castle_Windsor_Demo.Implementation;
using Castle_Windsor_Demo.Interfaces;

namespace Castle_Windsor_Demo.Registration
{
    public class ServicesInstaller : IWindsorInstaller
    {
        public void Install(IWindsorContainer container, IConfigurationStore store)
        {
            // Register Generic Type of sql repository, we have made this to be transient
            // as we want a new version of this each time.
            container.Register(
                Component.For(typeof (IRepository<>))
                    .ImplementedBy(typeof (SqlRepository<>)).LifeStyle.Transient);

            // register by only using interface (this will not work - we have to proxy it)
            //container.Register(
            //    Component.For(typeof (INamedInterface)));

            // Register a component by name - to be done if you have multiple implementations of the same interface
            container.Register(
                Component.For(typeof(INamedInterface)).ImplementedBy(typeof(NamedInterface)).Named("NamedInterface"));

        }
    }
}