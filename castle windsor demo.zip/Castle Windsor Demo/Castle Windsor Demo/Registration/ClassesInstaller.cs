﻿using Castle.MicroKernel.Registration;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;
using Castle_Windsor_Demo.Implementation;
using Castle_Windsor_Demo.Interfaces;
using Castle_Windsor_Demo.Repositories;
using Castle_Windsor_Demo.Services;

namespace Castle_Windsor_Demo.Registration
{
    public class ClassesInstaller : IWindsorInstaller
    {
        public void Install(IWindsorContainer container, IConfigurationStore store)
        {
            // Simple Fluent API for registering a type against an interface
            container.Register(Component.For<IUnitOfWork>().ImplementedBy<SqlUnitOfWork>());
            container.Register(Component.For<ICar>().ImplementedBy<Porsche>());
            container.Register(Component.For<ICar>().ImplementedBy<Mercedes>());
            container.Register(Component.For<IInsaneCar>().ImplementedBy<Bugatti>().Named("Bugatti"));
            container.Register(Component.For<IInsaneCar>().ImplementedBy<Koenigsegg>().Named("Koenigsegg"));
            container.Register(Component.For<IBike>().ImplementedBy<Ducati>());
            container.Register(Component.For<IProcessor>().ImplementedBy<Processor>());

            // Registering an instance of a class
            var bmw = new Bmw();
            container.Register(
                Component.For<ICar>().Instance(bmw)
                );

            // Registering with the ability to inspect the class when its created
            container.Register(
                Component.For<ISuperCar>()
                    .ImplementedBy<Ferrari>()
                    .OnCreate((kernel, instance) => instance.TellTheCarToStart())
                );

            // In-line dependencies
            const string logDirectory = @"some directory";

            container.Register(
                Component.For<ILogService>().ImplementedBy<LogService>()
                    .DependsOn(Dependency.OnValue("LogDirectory", logDirectory))
            );
        }
    }
}