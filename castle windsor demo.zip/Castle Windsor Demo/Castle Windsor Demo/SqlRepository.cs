﻿using Castle_Windsor_Demo.Interfaces;

namespace Castle_Windsor_Demo
{
    public class SqlRepository<T> : IRepository<T> where T: IUnitOfWork
    {
        private readonly T _type;

        public SqlRepository(T type)
        {
            _type = type;
        }

        public void RecordStartingCar()
        {
            _type.MakeDatabaseCall();
        }
    }
}